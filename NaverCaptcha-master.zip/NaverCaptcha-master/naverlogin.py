from sites.naver import Naver
import time

if __name__ == "__main__":
    naver = Naver('matrixsj', 'nagarjuna6')
    try:
        #naver.clipboard_login(naver.ID, naver.PW)
        naver.win32api_login('matrixsj', 'nagarjuna6')
    finally:
        time.sleep(5)
       # naver.driver.quit()
